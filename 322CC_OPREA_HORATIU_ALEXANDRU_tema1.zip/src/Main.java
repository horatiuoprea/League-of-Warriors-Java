import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

class LoginPage {
    private List<Account> accounts_list;

    public LoginPage(List<Account> accounts) {
        this.accounts_list = accounts;
        createLoginUI();
    }

    private void createLoginUI() {
        JFrame frame = new JFrame("Pagina de Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 200);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel emailLabel = new JLabel("Email:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        frame.add(emailLabel, gbc);

        JTextField emailField = new JTextField(20);
        gbc.gridx = 1;
        frame.add(emailField, gbc);

        JLabel passwordLabel = new JLabel("Parola:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        frame.add(passwordLabel, gbc);

        JPasswordField passwordField = new JPasswordField(20);
        gbc.gridx = 1;
        frame.add(passwordField, gbc);

        JButton loginButton = new JButton("Login");
        gbc.gridx = 1;
        gbc.gridy = 2;
        frame.add(loginButton, gbc);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());

                boolean emailValid = false;
                boolean passwordValid = false;

                for (Account acc : accounts_list) {
                    if (email.equals(acc.getAccountData().getLoginData().getMail())) {
                        emailValid = true;
                        if (password.equals(acc.getAccountData().getLoginData().getPsw())) {
                            passwordValid = true;
                        }
                        break;
                    }
                }

                if (!emailValid) {
                    JOptionPane.showMessageDialog(frame, "Email invalid!", "Eroare", JOptionPane.ERROR_MESSAGE);
                } else if (!passwordValid) {
                    JOptionPane.showMessageDialog(frame, "Parola gresita!", "Eroare", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Logat cu succes!");
                }
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        List<Account> accounts_list = JsonInput.deserializeAccounts();
        new LoginPage(accounts_list);
    }
}

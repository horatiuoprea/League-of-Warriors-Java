import java.util.*;

public class Game {

    private ArrayList<Account> acconuts_list;
    private Grid Map;

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Account acc : acconuts_list) {
            sb.append(
                    acc.getAccountData().getLoginData().getMail() + "\n" + acc.getAccountData().getLoginData().getPsw()
                            + "\n" + acc.getAccountData().getName() + "\n" + acc.getAccountData().getCountry() + "\n"
                            + acc.getGamesPlayed() + "\n");
            for (String game : acc.getAccountData().getFavoriteGames()) {
                sb.append(game + "\n");
            }
            sb.append("\n");
            for (Character player : acc.getAccountCharacters()) {
                sb.append(player.current_health + " " + player.max_health + " " + player.current_mana + " "
                        + player.max_mana + " " + player.fire_imune + " " + player.ice_imune + " " + player.earth_imune
                        + " " + player.character_name + " " + player.character_exp + " " + player.character_level + " "
                        + player.character_strength + " " + player.character_charisma + " " + player.character_dexterity
                        + " " + player.main_atribute);
                sb.append("\n");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public CellEntityType show_options(CellEntityType type)
            throws InvalidCommandException, ImpossibleMove, QuitGame, Game_Over {

        System.out.println("Mutari valide:");

        boolean ok_right = true, ok_left = true, ok_up = true, ok_down = true;
        if (Map.get_current_Cell().getPozY() + 1 == Map.getNrCol()) {
            ok_right = false;
        } else {
            System.out.println("Right");
        }
        if (Map.get_current_Cell().getPozY() == 0) {
            ok_left = false;
        } else {
            System.out.println("Left");
        }
        if (Map.get_current_Cell().getPozX() == 0) {
            ok_up = false;
        } else {
            System.out.println("Up");
        }
        if (Map.get_current_Cell().getPozX() + 1 == Map.getNrLin()) {
            ok_down = false;
        } else {
            System.out.println("Down");
        }

        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();

        if (line.isEmpty()) {
            throw new InvalidCommandException();
        }

        char command = line.charAt(0);

        if (command == 'q') {
            throw new QuitGame();
        }

        if (command != 'w' && command != 'a' && command != 's' && command != 'd')
            throw new InvalidCommandException();
        else if (command == 'w') {
            if (ok_up) {
                return Map.goNorth(type);
            } else {
                throw new ImpossibleMove();
            }
        } else if (command == 'a') {
            if (ok_left) {
                return Map.goWest(type);
            } else {
                throw new ImpossibleMove();
            }
        } else if (command == 's') {
            if (ok_down) {
                return Map.goSouth(type);
            } else {
                throw new ImpossibleMove();
            }
        } else {
            if (ok_right) {
                return Map.goEast(type);
            } else {
                throw new ImpossibleMove();
            }
        }
    }

    public void show_map() {
        for (int i = 0; i < Map.getNrLin(); i++) {
            for (int j = 0; j < Map.getNrCol(); j++) {
                if (Map.getCell(i, j).getType() == CellEntityType.VOID) {
                    if (Map.getCell(i, j).getVisited() == 1) {
                        System.out.print("V  ");
                    } else {
                        System.out.print("N  ");
                    }
                } else if (Map.getCell(i, j).getType() == CellEntityType.SANCTUARY) {
                    if (Map.getCell(i, j).getVisited() == 1) {
                        System.out.print("S  ");
                    } else {
                        System.out.print("N  ");
                    }
                } else if (Map.getCell(i, j).getType() == CellEntityType.ENEMY) {
                    if (Map.getCell(i, j).getVisited() == 1) {
                        System.out.print("E  ");
                    } else {
                        System.out.print("N  ");
                    }
                } else if (Map.getCell(i, j).getType() == CellEntityType.PORTAL) {
                    if (Map.getCell(i, j).getVisited() == 1) {
                        System.out.print("F  ");
                    } else {
                        System.out.print("N  ");
                    }
                } else {
                    System.out.print("P  ");
                }
            }
            System.out.print("\n");
        }
    }

    public void remove_map() {
        for (int i = 0; i < Map.getNrLin(); i++) {
            Map.removeAll(Map.get(i));
        }
        Map.setInstance(null);
    }

    public void next_level() {

        Random random = new Random();
        int lines = 3 + random.nextInt(8);
        int columns = 3 + random.nextInt(8);
        int start_x = random.nextInt(lines);
        int start_y = random.nextInt(columns);

        Map = Grid.construct_grid(lines, columns, Map.get_current_Character(),
                new Cell(start_x, start_y, CellEntityType.PLAYER, 1));
    }

    public void init_void() {

        for (int i = 0; i < Map.getNrLin(); i++)
            for (int j = 0; j < Map.getNrCol(); j++)
                if (Map.get(i).get(j).getType() != CellEntityType.PLAYER
                        && Map.get(i).get(j).getType() != CellEntityType.VOID) {
                    Map.get(i).get(j).setType(CellEntityType.VOID);
                }
    }

    public void run() {
        acconuts_list = JsonInput.deserializeAccounts();
        Scanner scanner = new Scanner(System.in);
        int idx;
        while (true) {
            System.out.println("Introdu email: ");
            String email = scanner.nextLine();
            boolean email_valid = false;
            for (Account acc : acconuts_list) {
                if (email.equals(acc.getAccountData().getLoginData().getMail())) {
                    email_valid = true;
                    break;
                }
            }
            if (email_valid) {
                break;
            }
            System.out.println("Email invalid");
        }
        while (true) {
            System.out.println("Introdu parola: ");
            String psw = scanner.nextLine();
            boolean psw_valid = false;
            idx = 0;
            for (Account acc : acconuts_list) {
                if (psw.equals(acc.getAccountData().getLoginData().getPsw())) {
                    psw_valid = true;
                    break;
                }
                idx++;
            }
            if (psw_valid) {
                break;
            }
            System.out.println("Parola gresita");
        }
        System.out.println("Logat cu succes!\n");
        Account log_acc = acconuts_list.get(idx);
        // check for out of bounds exception
        System.out.println("Alege-ti personajul");
        int i = 0, idx_pers;
        for (Character chr : log_acc.getAccountCharacters()) {
            i++;
            System.out.println(i + ". " + chr.character_name);
        }
        while (true) {
            idx_pers = scanner.nextInt();
            if (idx_pers > 0 && idx_pers <= log_acc.getAccountCharacters().size()) {
                System.out.println(
                        "Ai ales personajul: " + log_acc.getAccountCharacters().get(idx_pers - 1).character_name);
                break;
            } else {
                System.out.println("Index eronat");
            }
        }

        while (true) {

            System.out.println("Alege modul jocului: Play(p) sau Test(t)");
            String line = scanner.nextLine();

            if (line.isEmpty()) {
                System.out.println("Introdu o comanda");
                continue;
            }

            char command = line.charAt(0);

            if (command == 'p') {

                Random random = new Random();
                int lines = 3 + random.nextInt(8);
                int columns = 3 + random.nextInt(8);
                int start_x = random.nextInt(lines);
                int start_y = random.nextInt(columns);

                Map = Grid.construct_grid(lines, columns, log_acc.getAccountCharacters().get(idx_pers - 1),
                        new Cell(start_x, start_y, CellEntityType.PLAYER, 1));
                break;
            } else if (command == 't') {

                Map = Grid.construct_grid(5, 5, log_acc.getAccountCharacters().get(idx_pers - 1),
                        new Cell(0, 0, CellEntityType.PLAYER, 1));
                init_void();
                Map.getCell(0, 3).setType(CellEntityType.SANCTUARY);
                Map.getCell(1, 3).setType(CellEntityType.SANCTUARY);
                Map.getCell(2, 0).setType(CellEntityType.SANCTUARY);
                Map.getCell(4, 3).setType(CellEntityType.SANCTUARY);
                Map.getCell(3, 4).setType(CellEntityType.ENEMY);
                Map.getCell(4, 4).setType(CellEntityType.PORTAL);

                break;
            } else {
                System.out.println("Mod invalid");
            }

        }

        CellEntityType type = CellEntityType.VOID;

        while (true) {
            show_map();
            try {
                type = show_options(type);
                if (type == null) {
                    remove_map();
                    next_level();
                    type = CellEntityType.VOID;
                    System.out.println("Ai gasit portalul!");
                }
            } catch (InvalidCommandException e) {
                System.out.println(e.getMessage() + "\n" + "Introdu o comada valida");
            } catch (ImpossibleMove e) {
                System.out.println(e.getMessage() + "\n" + "Introdu o mutare valida");
            } catch (QuitGame e) {
                System.out.println("Exited the game");
                break;
            } catch (Game_Over e) {
                System.out.println("Game Over!");
                break;
            }
        }
    }
}

enum CellEntityType {
    PLAYER, VOID, ENEMY, SANCTUARY, PORTAL;
}

class Game_Over extends Exception {
    public Game_Over() {
        super();
    }
}

class InvalidCommandException extends Exception {
    public InvalidCommandException() {
        super("Comanda invalida");
    }
}

class ImpossibleMove extends Exception {
    public ImpossibleMove() {
        super("Mutare invalida");
    }
}

class QuitGame extends Exception {
    public QuitGame() {
        super();
    }
}

class Grid extends ArrayList<ArrayList<Cell>> {
    private int nr_lin, nr_col;
    private Character current_Character;
    private Cell current_Cell;
    private static Grid instance = null;

    private Grid(int nr_lin, int nr_col, Character current_Character, Cell current_Cell) {
        this.nr_lin = nr_lin;
        this.nr_col = nr_col;
        this.current_Character = current_Character;
        this.current_Cell = current_Cell;

        for (int i = 0; i < nr_lin; i++) {
            ArrayList<Cell> row = new ArrayList<>();
            for (int j = 0; j < nr_col; j++) {
                if (i == current_Cell.getPozX() && j == current_Cell.getPozY())
                    row.add(current_Cell);
                else {
                    row.add(new Cell(i, j, CellEntityType.VOID, 0));
                }
            }
            add(row);
        }

        Random random = new Random();

        int min = Math.min(nr_lin, nr_col);
        int nr_sanct, nr_enemy, nr_portal = 1;

        while (true) {
            nr_sanct = 2 + random.nextInt(min);
            nr_enemy = 4 + random.nextInt(min);
            if (nr_enemy + nr_sanct <= nr_lin * nr_col - 2)
                break;
        }

        while (true) {
            if (nr_sanct == 0) {
                break;
            } else {
                int poz_x = random.nextInt(nr_lin);
                int poz_y = random.nextInt(nr_col);
                if (getCell(poz_x, poz_y).getType() == CellEntityType.VOID) {
                    nr_sanct--;
                    getCell(poz_x, poz_y).setType(CellEntityType.SANCTUARY);
                }
            }
        }

        while (true) {
            if (nr_enemy == 0) {
                break;
            } else {
                int poz_x = random.nextInt(nr_lin);
                int poz_y = random.nextInt(nr_col);
                if (getCell(poz_x, poz_y).getType() == CellEntityType.VOID) {
                    nr_enemy--;
                    getCell(poz_x, poz_y).setType(CellEntityType.ENEMY);
                }
            }
        }

        while (true) {
            if (nr_portal == 0) {
                break;
            } else {
                int poz_x = random.nextInt(nr_lin);
                int poz_y = random.nextInt(nr_col);
                if (getCell(poz_x, poz_y).getType() == CellEntityType.VOID) {
                    nr_portal--;
                    getCell(poz_x, poz_y).setType(CellEntityType.PORTAL);
                }
            }
        }
    }

    public static Grid construct_grid(int nr_lin, int nr_col, Character current_Character, Cell current_Cell) {
        if(instance == null) {
            instance = new Grid(nr_lin, nr_col, current_Character, current_Cell);
        }
        return instance;
    }

    public String character_status() {
        StringBuilder sb = new StringBuilder();
        sb.append(current_Character.character_name + "\n");
        sb.append("Health: " + current_Character.current_health + "\n");
        sb.append("Mana: " + current_Character.current_mana + "\n");
        sb.append("Exp: " + current_Character.character_exp + "\n");
        sb.append("Level: " + current_Character.character_level + "\n");
        sb.append("Imunity to: ");
        if (current_Character.earth_imune) {
            sb.append("Earth ");
        }
        if (current_Character.fire_imune) {
            sb.append("Fire ");
        }
        if (current_Character.ice_imune) {
            sb.append("Ice ");
        }
        return sb.toString();
    }

    public String enenmy_status(Entity enemy) {
        StringBuilder sb = new StringBuilder();
        sb.append("Inamic\n");
        sb.append("Health: " + enemy.current_health + "\n");
        sb.append("Mana: " + enemy.current_mana + "\n");
        sb.append("Imunity to: ");
        if (enemy.earth_imune) {
            sb.append("Earth ");
        }
        if (enemy.fire_imune) {
            sb.append("Fire ");
        }
        if (enemy.ice_imune) {
            sb.append("Ice ");
        }
        return sb.toString();
    }

    public String show_spells() {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Spell sp : get_current_Character().spell_list) {
            sb.append(i + "\n" + sp.toString());
            i++;
        }
        return sb.toString();
    }

    public String show_enemy_spells(Entity enemy) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Spell sp : enemy.spell_list) {
            sb.append(i + "\n" + sp.toString());
            i++;
        }
        return sb.toString();
    }

    public boolean fight() {

        Random random = new Random();
        ArrayList<Spell> aux_spells = new ArrayList<Spell>();
        boolean win = false, imune1, imune2, imune3;
        Scanner scanner = new Scanner(System.in);

        while (true) {
            imune1 = random.nextBoolean();
            imune2 = random.nextBoolean();
            imune3 = random.nextBoolean();
            if (((imune1 && imune2 && imune3) == false) && (imune1 || imune2 || imune3)) {
                break;
            }
        }

        Entity enemy = new Enemy(50 + random.nextInt(50), 100 + random.nextInt(50), 50 + random.nextInt(50),
                70 + random.nextInt(50), imune1, imune2, imune3, new ArrayList<Spell>());

        System.out.println("Lupta a inceput");
        while (true) {
            System.out.println(character_status());
            System.out.println(show_spells());
            System.out.println(enenmy_status(enemy));
            System.out.println(show_enemy_spells(enemy));
            int attack;
            while (true) {
                try {
                    attack = scanner.nextInt();
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Introdu un numar");
                    scanner.nextLine();
                }
            }
            System.out.println("Atac ales de player: " + attack);
            if (attack >= 0 && attack < get_current_Character().spell_list.size()) {
//                get_current_Character().use_ability(get_current_Character().spell_list.get(attack), enemy);
                if (get_current_Character().current_mana < get_current_Character().spell_list.get(attack).spell_mana) {
                    System.out.println("Nu ai suficienta mana pentru acest spell");
                    enemy.normal_attack();
                }
                else {
                    enemy.accept(get_current_Character().spell_list.get(attack));
                    get_current_Character().current_mana -= get_current_Character().spell_list.get(attack).spell_mana;
                    aux_spells.add(get_current_Character().spell_list.get(attack));
                    get_current_Character().spell_list.remove(attack);
                }
            } else {
                enemy.normal_attack();
            }

            if (enemy.current_health == 0) {
                System.out.println("Inamic infrant!" + "\n" + enenmy_status(enemy));
                get_current_Character().spell_list.addAll(aux_spells);
                win = true;
                break;
            }

            if (enemy.spell_list.isEmpty()) {
                get_current_Character().normal_attack();
            } else {
                int enemy_attack = random.nextInt(enemy.spell_list.size());
                System.out.println("Atac ales de inamic: " + enemy_attack);
//                enemy.use_ability(enemy.spell_list.get(enemy_attack), get_current_Character());
                if (enemy.current_mana < enemy.spell_list.get(enemy_attack).spell_mana) {
                    System.out.println("Nu ai suficienta mana pentru acest spell");
                    get_current_Character().normal_attack();
                }
                else {
                    get_current_Character().accept(enemy.spell_list.get(enemy_attack));
                    enemy.current_mana -= enemy.spell_list.get(enemy_attack).spell_mana;
                    enemy.spell_list.remove(enemy_attack);
                }
            }

            if (get_current_Character().current_health == 0) {
                System.out.println("Player infrant!" + "\n" + character_status());
                win = false;
                break;
            }
        }
        return win;
    }

    public CellEntityType goNorth(CellEntityType type) throws Game_Over {
        get_current_Cell().setType(type);
        set_current_Cell(getCell(get_current_Cell().getPozX() - 1, get_current_Cell().getPozY()));
        CellEntityType new_type = get_current_Cell().getType();
        if (new_type == CellEntityType.SANCTUARY && get_current_Cell().getVisited() == 0) {
            Random random = new Random();
            get_current_Character().regenerate_health(get_current_Character().current_health
                    + random.nextInt(1 + get_current_Character().max_health - get_current_Character().current_health));
            get_current_Character().regenerate_mana(get_current_Character().current_mana
                    + random.nextInt(1 + get_current_Character().max_mana - get_current_Character().current_mana));
            System.out.println("Ai gasit un sanctuar\n" + character_status());
        }
        if (new_type == CellEntityType.PORTAL) {
            get_current_Character().regenerate_health(get_current_Character().max_health);
            get_current_Character().regenerate_mana(get_current_Character().max_mana);
            get_current_Character().character_level++;
            get_current_Character().character_exp = get_current_Character().character_exp
                    + 5 * get_current_Character().character_level;
            return null;
        }
        if (new_type == CellEntityType.ENEMY && get_current_Cell().getVisited() == 0) {
            Random random = new Random();
            if (fight() == false) {
                throw new Game_Over();
            } else {
                get_current_Character().regenerate_health(get_current_Character().current_health
                        + random.nextInt(
                                1 + get_current_Character().max_health - get_current_Character().current_health));
                get_current_Character().regenerate_mana(get_current_Character().current_mana
                        + random.nextInt(1 + get_current_Character().max_mana - get_current_Character().current_mana));
            }
        }
        get_current_Cell().setType(CellEntityType.PLAYER);
        get_current_Cell().setVisited(1);
        return new_type;
    }

    public CellEntityType goSouth(CellEntityType type) throws Game_Over {
        get_current_Cell().setType(type);
        set_current_Cell(getCell(get_current_Cell().getPozX() + 1, get_current_Cell().getPozY()));
        CellEntityType new_type = get_current_Cell().getType();
        if (new_type == CellEntityType.SANCTUARY && get_current_Cell().getVisited() == 0) {
            Random random = new Random();
            get_current_Character().regenerate_health(get_current_Character().current_health
                    + random.nextInt(1 + get_current_Character().max_health - get_current_Character().current_health));
            get_current_Character().regenerate_mana(get_current_Character().current_mana
                    + random.nextInt(1 + get_current_Character().max_mana - get_current_Character().current_mana));
            System.out.println("Ai gasit un sanctuar\n" + character_status());
        }
        if (new_type == CellEntityType.PORTAL) {
            get_current_Character().regenerate_health(get_current_Character().max_health);
            get_current_Character().regenerate_mana(get_current_Character().max_mana);
            get_current_Character().character_level++;
            get_current_Character().character_exp = get_current_Character().character_exp
                    + 5 * get_current_Character().character_level;
            return null;
        }
        if (new_type == CellEntityType.ENEMY && get_current_Cell().getVisited() == 0) {
            Random random = new Random();
            if (fight() == false) {
                throw new Game_Over();
            } else {
                get_current_Character().regenerate_health(get_current_Character().current_health
                        + random.nextInt(
                                1 + get_current_Character().max_health - get_current_Character().current_health));
                get_current_Character().regenerate_mana(get_current_Character().current_mana
                        + random.nextInt(1 + get_current_Character().max_mana - get_current_Character().current_mana));
            }
        }
        get_current_Cell().setType(CellEntityType.PLAYER);
        get_current_Cell().setVisited(1);
        return new_type;
    }

    public CellEntityType goWest(CellEntityType type) throws Game_Over {
        get_current_Cell().setType(type);
        set_current_Cell(getCell(get_current_Cell().getPozX(), get_current_Cell().getPozY() - 1));
        CellEntityType new_type = get_current_Cell().getType();
        if (new_type == CellEntityType.SANCTUARY && get_current_Cell().getVisited() == 0) {
            Random random = new Random();
            get_current_Character().regenerate_health(get_current_Character().current_health
                    + random.nextInt(1 + get_current_Character().max_health - get_current_Character().current_health));
            get_current_Character().regenerate_mana(get_current_Character().current_mana
                    + random.nextInt(1 + get_current_Character().max_mana - get_current_Character().current_mana));
            System.out.println("Ai gasit un sanctuar\n" + character_status());
        }
        if (new_type == CellEntityType.PORTAL) {
            get_current_Character().regenerate_health(get_current_Character().max_health);
            get_current_Character().regenerate_mana(get_current_Character().max_mana);
            get_current_Character().character_level++;
            get_current_Character().character_exp = get_current_Character().character_exp
                    + 5 * get_current_Character().character_level;
            return null;
        }
        if (new_type == CellEntityType.ENEMY && get_current_Cell().getVisited() == 0) {
            Random random = new Random();
            if (fight() == false) {
                throw new Game_Over();
            } else {
                get_current_Character().regenerate_health(get_current_Character().current_health
                        + random.nextInt(
                                1 + get_current_Character().max_health - get_current_Character().current_health));
                get_current_Character().regenerate_mana(get_current_Character().current_mana
                        + random.nextInt(1 + get_current_Character().max_mana - get_current_Character().current_mana));
            }
        }
        get_current_Cell().setType(CellEntityType.PLAYER);
        get_current_Cell().setVisited(1);
        return new_type;
    }

    public CellEntityType goEast(CellEntityType type) throws Game_Over {
        get_current_Cell().setType(type);
        set_current_Cell(getCell(get_current_Cell().getPozX(), get_current_Cell().getPozY() + 1));
        CellEntityType new_type = get_current_Cell().getType();
        if (new_type == CellEntityType.SANCTUARY && get_current_Cell().getVisited() == 0) {
            Random random = new Random();
            get_current_Character().regenerate_health(get_current_Character().current_health
                    + random.nextInt(1 + get_current_Character().max_health - get_current_Character().current_health));
            get_current_Character().regenerate_mana(get_current_Character().current_mana
                    + random.nextInt(1 + get_current_Character().max_mana - get_current_Character().current_mana));
            System.out.println("Ai gasit un sanctuar\n" + character_status());
        }
        if (new_type == CellEntityType.PORTAL) {
            get_current_Character().regenerate_health(get_current_Character().max_health);
            get_current_Character().regenerate_mana(get_current_Character().max_mana);
            get_current_Character().character_level++;
            get_current_Character().character_exp = get_current_Character().character_exp
                    + 5 * get_current_Character().character_level;
            return null;
        }
        if (new_type == CellEntityType.ENEMY && get_current_Cell().getVisited() == 0) {
            Random random = new Random();
            if (fight() == false) {
                throw new Game_Over();
            } else {
                get_current_Character().regenerate_health(get_current_Character().current_health
                        + random.nextInt(
                                1 + get_current_Character().max_health - get_current_Character().current_health));
                get_current_Character().regenerate_mana(get_current_Character().current_mana
                        + random.nextInt(1 + get_current_Character().max_mana - get_current_Character().current_mana));
            }
        }
        get_current_Cell().setType(CellEntityType.PLAYER);
        get_current_Cell().setVisited(1);
        return new_type;
    }

    public int getNrLin() {
        return nr_lin;
    }

    public void setNrLin(int nr_lin) {
        this.nr_lin = nr_lin;
    }

    public int getNrCol() {
        return nr_col;
    }

    public void setNrCol(int nr_col) {
        this.nr_col = nr_col;
    }

    public Character get_current_Character() {
        return current_Character;
    }

    public Cell get_current_Cell() {
        return current_Cell;
    }

    public void set_current_Cell(Cell current_Cell) {
        this.current_Cell = current_Cell;
    }

    public Cell getCell(int row, int col) {
        if (row >= 0 && row < nr_lin && col >= 0 && col < nr_col) {
            return get(row).get(col);
        } else {
            throw new IndexOutOfBoundsException("Invalid cell coordinates!");
        }
    }

    public void setCell(int row, int col, Cell cell) {
        if (row >= 0 && row < nr_lin && col >= 0 && col < nr_col) {
            get(row).set(col, cell);
        } else {
            throw new IndexOutOfBoundsException("Invalid cell coordinates!");
        }
    }

    public Grid getInstance(){
        return instance;
    }

    public void setInstance(Grid instance){
        this.instance = instance;
    }
}

class Cell {
    private int poz_x, poz_y;
    private CellEntityType type;
    private int visited;

    public Cell(int poz_x, int poz_y, CellEntityType type, int visited) {
        this.poz_x = poz_x;
        this.poz_y = poz_y;
        this.type = type;
        this.visited = visited;
    }

    public int getPozX() {
        return poz_x;
    }

    public void setPozX(int poz_x) {
        this.poz_x = poz_x;
    }

    public int getPozY() {
        return poz_y;
    }

    public void setPozY(int poz_y) {
        this.poz_y = poz_y;
    }

    public CellEntityType getType() {
        return type;
    }

    public int getVisited() {
        return visited;
    }

    public void setType(CellEntityType type) {
        this.type = type;
    }

    public void setVisited(int visited) {
        this.visited = visited;
    }
}

class Account {
    private Information account_data;
    private ArrayList<Character> account_Characters;
    private int games_played;

    public Information getAccountData() {
        return account_data;
    }

    public ArrayList<Character> getAccountCharacters() {
        return account_Characters;
    }

    public int getGamesPlayed() {
        return games_played;
    }

    public Account(ArrayList<Character> account_Characters, int games_played, Information account_data) {
        this.account_Characters = account_Characters;
        this.games_played = games_played;
        this.account_data = account_data;
    }

    static class Information {
        private Credentials login_data;
        private String name, country;
        private SortedSet<String> favorite_games;

        public Credentials getLoginData() {
            return login_data;
        }

        public String getName() {
            return name;
        }

        public String getCountry() {
            return country;
        }

        public SortedSet<String> getFavoriteGames() {
            return favorite_games;
        }

        public Information(Info_Builder builder) {
            this.login_data = builder.login_data;
            this.favorite_games = builder.favorite_games;
            this.name = builder.name;
            this.country = builder.country;
        }

        public static class Info_Builder {
            private Credentials login_data;
            private SortedSet<String> favorite_games;
            private String name;
            private String country;
            public Info_Builder() {}
            public Info_Builder setLogin_data(Credentials login_data) {
                this.login_data = login_data;
                return this;
            }
            public Info_Builder setFavorite_games(SortedSet<String> favorite_games) {
                this.favorite_games = favorite_games;
                return this;
            }
            public Info_Builder setName(String name) {
                this.name = name;
                return this;
            }
            public Info_Builder setCountry(String country) {
                this.country = country;
                return this;
            }
            public Information build() {
                return new Information(this);
            }
        }
    }
}

class Credentials {
    private String mail, psw;

    public String getMail() {
        return mail;
    }

    public String getPsw() {
        return psw;
    }

    public Credentials(String mail, String psw) {
        this.mail = mail;
        this.psw = psw;
    }
}

import java.util.*;

public class Test {
    public static void main(String[] args) {
        Game game = new Game();
        game.run();
    }
}
